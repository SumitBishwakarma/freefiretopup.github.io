import React, { useState } from 'react';
import { Layers, Zap, Box, Code2, Monitor, Download, Github, Maximize2, Minimize2 } from 'lucide-react';
import CodeEditor from './components/CodeEditor';
import PreviewFrame from './components/PreviewFrame';
import AIPromptModal from './components/AIPromptModal';
import { generateCodeFromPrompt } from './services/geminiService';
import { CodeState, EditorTab } from './types';

const INITIAL_CODE: CodeState = {
  html: `<div class="card">\n  <div class="glow"></div>\n  <h2>Aether</h2>\n  <p>Future of Coding</p>\n</div>`,
  css: `body {\n  background: #000;\n  color: white;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  height: 100vh;\n}\n\n.card {\n  position: relative;\n  padding: 40px;\n  background: rgba(255,255,255,0.05);\n  border-radius: 20px;\n  backdrop-filter: blur(10px);\n  border: 1px solid rgba(255,255,255,0.1);\n  overflow: hidden;\n}\n\nh2 {\n  font-size: 2.5rem;\n  margin: 0;\n  background: linear-gradient(to right, #06b6d4, #8b5cf6);\n  -webkit-background-clip: text;\n  -webkit-text-fill-color: transparent;\n}`,
  js: `console.log('Aether Code initialized...');\n\nconst card = document.querySelector('.card');\ncard.addEventListener('mousemove', (e) => {\n  // Add interactive hover logic here\n});`
};

const App: React.FC = () => {
  const [code, setCode] = useState<CodeState>(INITIAL_CODE);
  const [activeTab, setActiveTab] = useState<EditorTab>('html');
  const [isAIModalOpen, setAIModalOpen] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isFullScreen, setIsFullScreen] = useState(false);

  const handleCodeChange = (type: EditorTab, value: string) => {
    setCode(prev => ({ ...prev, [type]: value }));
  };

  const handleAIGenerate = async (prompt: string) => {
    setIsGenerating(true);
    try {
      const currentContext = JSON.stringify(code);
      const result = await generateCodeFromPrompt(prompt, currentContext);
      setCode({
        html: result.html,
        css: result.css,
        js: result.js
      });
      setAIModalOpen(false);
    } catch (error) {
      alert("Failed to generate code. Please try again.");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="flex h-screen w-full bg-[#0f172a] text-slate-200 overflow-hidden relative">
      {/* Background Decor */}
      <div className="absolute top-[-20%] right-[-10%] w-[800px] h-[800px] bg-blue-600/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-20%] left-[-10%] w-[600px] h-[600px] bg-cyan-600/10 rounded-full blur-[100px] pointer-events-none" />

      {/* Main Container */}
      <div className="z-10 flex flex-col w-full h-full backdrop-blur-3xl">
        
        {/* Header */}
        <header className="h-16 flex items-center justify-between px-6 border-b border-white/5 bg-[#0f172a]/80 backdrop-blur-md shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-900/50">
              <Layers className="text-white" size={18} />
            </div>
            <h1 className="font-bold text-xl tracking-tight text-white">Aether Code</h1>
          </div>
          
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setAIModalOpen(true)}
              className="flex items-center gap-2 px-4 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-full text-sm transition-all hover:scale-105 group"
            >
              <Zap size={16} className="text-yellow-400 group-hover:text-yellow-300" />
              <span className="bg-gradient-to-r from-yellow-200 to-amber-200 bg-clip-text text-transparent font-medium">AI Assist</span>
            </button>
            <div className="h-6 w-px bg-white/10" />
            <a href="#" className="p-2 text-slate-400 hover:text-white transition-colors">
              <Github size={20} />
            </a>
          </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 flex flex-col lg:flex-row overflow-hidden relative">
          
          {/* Editor Pane */}
          {!isFullScreen && (
            <div className="flex-1 flex flex-col min-w-0 border-r border-white/5 transition-all duration-300 ease-in-out">
              {/* Tabs */}
              <div className="flex items-center h-12 border-b border-white/5 px-2 bg-slate-900/50 shrink-0">
                {(['html', 'css', 'js'] as EditorTab[]).map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`
                      relative px-6 h-full flex items-center gap-2 text-sm font-medium transition-colors
                      ${activeTab === tab ? 'text-cyan-400' : 'text-slate-500 hover:text-slate-300'}
                    `}
                  >
                    {tab === 'html' && <Box size={14} />}
                    {tab === 'css' && <Monitor size={14} />}
                    {tab === 'js' && <Code2 size={14} />}
                    <span className="uppercase">{tab}</span>
                    {activeTab === tab && (
                      <div className="absolute bottom-0 left-0 w-full h-[2px] bg-cyan-500 shadow-[0_-2px_8px_rgba(6,182,212,0.5)]" />
                    )}
                  </button>
                ))}
              </div>

              {/* Code Input */}
              <div className="flex-1 relative bg-[#0b1120]/50">
                <CodeEditor 
                  code={code[activeTab]} 
                  onChange={(val) => handleCodeChange(activeTab, val)} 
                  language={activeTab}
                  isActive={true}
                />
              </div>
              
              {/* Status Bar */}
              <div className="h-8 border-t border-white/5 flex items-center px-4 text-xs text-slate-500 bg-slate-900/80 shrink-0">
                <div className="flex items-center gap-2">
                   <div className="w-2 h-2 rounded-full bg-green-500/50 animate-pulse" />
                   Ready
                </div>
                <div className="flex-1" />
                <div>UTF-8</div>
              </div>
            </div>
          )}

          {/* Preview Pane */}
          <div className={`flex flex-col min-w-0 bg-black/20 gap-4 transition-all duration-300 ease-in-out ${isFullScreen ? 'flex-1 w-full p-2' : 'flex-1 p-4 lg:p-6'}`}>
             <div className="flex items-center justify-between mb-2 shrink-0 px-2">
                <div className="text-xs font-mono uppercase text-slate-500 tracking-wider">Live Preview</div>
                <div className="flex gap-2">
                  <button 
                    onClick={() => setIsFullScreen(!isFullScreen)}
                    className="p-1.5 rounded-md hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
                    title={isFullScreen ? "Minimize View" : "Full Screen View"}
                  >
                    {isFullScreen ? <Minimize2 size={16} /> : <Maximize2 size={16} />}
                  </button>
                  <button className="p-1.5 rounded-md hover:bg-white/10 text-slate-400 hover:text-white transition-colors">
                     <Download size={16} />
                  </button>
                </div>
             </div>
             <div className="flex-1 relative rounded-xl ring-1 ring-white/10 shadow-2xl h-full overflow-hidden bg-white">
               <PreviewFrame code={code} />
             </div>
          </div>

        </div>
      </div>

      <AIPromptModal 
        isOpen={isAIModalOpen} 
        onClose={() => setAIModalOpen(false)} 
        onSubmit={handleAIGenerate}
        isLoading={isGenerating}
      />
    </div>
  );
};

export default App;